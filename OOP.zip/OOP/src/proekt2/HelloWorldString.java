package proekt2;

public class HelloWorldString {
	public static void main(String[] args) {
		String firststring=new String("Hello");
		String secondstring=new String("World");
		System.out.println(firststring + " " + secondstring);
			}

		}

