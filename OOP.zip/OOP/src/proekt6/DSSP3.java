package proekt6;

public class DSSP3 {
	public static void main(String[] args) {
		String article1="chokolado";
		String price1="50";
		String quantity="5";
		String article2="sok";
		String price2="35";
		String unit="denar";
		int chocolateprice=Integer.parseInt(price1)*Integer.parseInt(quantity);
		int juiceprice=Integer.parseInt(price2)*Integer.parseInt(quantity);
		int totalPrice=chocolateprice+juiceprice;
		
		System.out.println("Smetka: ");
		System.out.println("Edno chokolado=");
	}
}
