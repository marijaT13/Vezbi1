package proekt3;

public class FirstLastIndex {
	public static void main(String[] args) {
		String firstName=new String("Marija");
		String secondName=new String("Tashevska");
		int index=808;
		System.out.println("Zdravo, jas sum "+ firstName + " "+ secondName +". ");
		System.out.println("Mojot broj na indeks e "+index+".");
		
		 
		
	}
}
