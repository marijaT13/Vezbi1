package proekt5;

public class DSSP2 {
	public static void main(String[] args) {
		String unit=new String("stepen");
		String value=new String("2.5");
		double temperature=Double.parseDouble(value);
		System.out.println("Temperaturata iznesuva "+(int)(temperature*10)+unit+".");
	}

}
